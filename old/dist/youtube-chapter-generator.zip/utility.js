// Utility functions for the YouTube Chapter Generator extension

/**
 * Extracts the video ID from a YouTube URL
 * @param {string} url - The YouTube URL
 * @returns {string|null} The video ID or null if not found
 */
function extractVideoId(url) {
  try {
    const urlObj = new URL(url);
    const searchParams = new URLSearchParams(urlObj.search);
    return searchParams.get('v');
  } catch (error) {
    console.error('Error extracting video ID:', error);
    return null;
  }
}

/**
 * Formats seconds into a timestamp (HH:MM:SS or MM:SS)
 * @param {number} seconds - Time in seconds
 * @returns {string} Formatted timestamp
 */
function formatTimeStamp(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  } else {
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
}

/**
 * Shows a notification to the user
 * @param {string} message - The message to display
 * @param {string} type - The type of message (success, error, info)
 */
function showNotification(message, type = 'info') {
  // This function would be implemented differently depending on where it's used
  console.log(`${type.toUpperCase()}: ${message}`);
}

// Export the functions if using modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    extractVideoId,
    formatTimeStamp,
    showNotification
  };
} 