# YouTube Chapter Generator

A Chrome extension that generates catchy YouTube chapter titles with timestamps using AI (OpenAI API) based on automatic transcripts from YouTube videos.

## Features

- Extracts video transcripts directly from YouTube videos
- Uses OpenAI's GPT model to generate engaging chapter titles with timestamps
- Easy-to-use Chrome extension interface
- Copy-to-clipboard functionality for easy pasting into YouTube descriptions

## Installation

### Chrome Extension

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top-right corner
4. Click "Load unpacked" and select the extension directory
5. The extension icon should now appear in your Chrome toolbar

Alternatively, you can package the extension:

```bash
# Install dependencies
npm install

# Package the extension
npm run package-extension
```

This will create a zip file in the `dist` directory that can be uploaded to the Chrome Web Store.

### Backend API

The backend API is hosted on Vercel at: `https://youtube-chapter-generator-oax3hbyx5-bohdans-projects-7ca0eede.vercel.app`

To set up your own instance of the backend:

1. Clone the repository
   ```bash
   git clone https://github.com/bohdan-s24/youtube-chapter-generator-api.git
   cd youtube-chapter-generator-api
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env.local` file with your OpenAI API key:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

4. Run the development server:
   ```bash
   npm run dev
   ```

5. Deploy to Vercel:
   ```bash
   # Install Vercel CLI if not installed
   npm install -g vercel

   # Deploy to Vercel
   vercel

   # For production deployment
   vercel --prod
   ```

## Usage

1. Navigate to a YouTube video
2. Click the YouTube Chapter Generator extension icon
3. Click "Generate Chapters"
4. Wait for the AI to process the transcript and generate chapters
5. Use the "Copy to Clipboard" button to copy the generated chapters
6. Paste into your YouTube video description

## How It Works

1. **Transcript Extraction**: The extension uses the YouTube Transcript API to fetch the video's subtitles.

2. **AI Processing**: The transcript is sent to the OpenAI API through our backend service, which processes the text and identifies key topics and appropriate timestamps.

3. **Chapter Generation**: The API returns well-formatted chapter titles with their corresponding timestamps that can be directly used in YouTube descriptions.

## Technologies Used

- JavaScript
- Chrome Extension APIs
- Next.js for the backend API
- OpenAI API for generating chapter titles
- YouTube Transcript API for extracting video transcripts

## Development

To modify the extension:

1. Edit the files in the extension directory
2. Reload the extension in Chrome by clicking the refresh icon on the extensions page

To modify the backend:

1. Edit the files in the `pages/api` directory
2. If you're running the development server, changes will be applied automatically

## License

MIT License 